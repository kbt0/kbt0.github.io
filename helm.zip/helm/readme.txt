# Helmプライグインをインストール

helm.componentを以下のフォルダに入れてください。
（なかったら作成してください）
[User]/ライブラリ/Audio/Plug-Ins/Components/

# GarageBandの設定

メニュー > 設定 > オーディオ/MIDI > 音源とエフェクト
で「Audio Unitsを有効にする」をチェックしてください。

トラックの設定からプラグインを選択してください。
AU Instruments > Matt Tytel > Helm
「Helm」をダブルクリックしてプラグインを開いてください。

# Presetsのインストール

BROWSEボタンをクリック > Import Bankボタンをクリック > preset.helmbankを選択してください。